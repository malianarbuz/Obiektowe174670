public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        Elf elf1=new Elf("Karol",23,"magazynier");
        Elf elf2=new Elf("Karweol",24,"magazynier");
        elf1.przedstawSie();
        Fabryka fabr=new Fabryka(34,23);
        fabr.dodajPracownika(elf1);
        fabr.dodajPracownika(elf2);
        System.out.println(fabr.najstarszyPracownik());
        Renifer renifer1=new Renifer("Rudolf1",11);
        Renifer renifer2=new Renifer("Rudolf2",10);
        renifer1.nakarmRenifera();
        System.out.println(renifer1.getPredkosc());
        Sanie sanki=new Sanie();
        sanki.dodajRenifera(renifer1);
        sanki.dodajRenifera(renifer2);
        sanki.dodajRenifera(renifer2);
        System.out.println(sanki.getListaReniferow());
        System.out.println(sanki.najwolniejszyRenifer());
        System.out.println(sanki.sumaPredkosci());

    }
}