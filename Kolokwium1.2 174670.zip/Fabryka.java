import java.util.ArrayList;
import java.util.Objects;
import java.util.concurrent.ExecutionException;

public class Fabryka {
    private ArrayList<Elf> listaElfow;
    private double dlGeo;
    private double szGeo;

    public Fabryka(double szGeo, double dlGeo) {
        if(szGeo > -90 || szGeo < 90)
            this.szGeo = szGeo;
        if(dlGeo > -180 || dlGeo < 180)
            this.dlGeo = dlGeo;
        this.listaElfow = new ArrayList<Elf>();
    }

    public ArrayList<Elf> getListaElfow() {
        return listaElfow;
    }

    public void setListaElfow(ArrayList<Elf> listaElfow) {
        if(listaElfow != null)
            this.listaElfow = listaElfow;
    }

    public double getDlGeo() {
        return dlGeo;
    }

    public void setDlGeo(double dlGeo) {
        if(dlGeo > -180 || dlGeo < 180)
            this.dlGeo = dlGeo;
    }

    public double getSzGeo() {
        return szGeo;
    }

    public void setSzGeo(double szGeo) {
        if(szGeo > -90 || szGeo < 90)
            this.szGeo = szGeo;
    }

    public void usunPracownika(Elf elf) {
        if(listaElfow.contains(elf)) {
            listaElfow.remove(elf);
        }
    }
    public void dodajPracownika(Elf elf) {
        if(!listaElfow.contains(elf)) {
            listaElfow.add(elf);
        }
    }
    public Elf najstarszyPracownik(){
        if(listaElfow.isEmpty())
            return null;
        Elf najstarszyElf=listaElfow.get(0);
        for(int i=1;i<listaElfow.size();i++){
            if(listaElfow.get(i).getWiek()>najstarszyElf.getWiek()){
                najstarszyElf=listaElfow.get(i);
            }
        }
        return najstarszyElf;
    }
}
