import java.util.ArrayList;
import java.util.Objects;

public class Sanie {
    private ArrayList<Renifer> listaReniferow;

    public Sanie() {
        this.listaReniferow = new ArrayList<Renifer>();
    }

    public ArrayList<Renifer> getListaReniferow() {
        return this.listaReniferow;
    }

    public void setListaReniferow(ArrayList<Renifer> listaReniferow) {
        if(listaReniferow != null) {
            this.listaReniferow = listaReniferow;
        }
    }

    @Override
    public String toString() {
        return "Sanie{" +
                "listaReniferow=" + listaReniferow +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Sanie sanie = (Sanie) o;
        return Objects.equals(listaReniferow, sanie.listaReniferow);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(listaReniferow);
    }

    public void dodajRenifera(Renifer renifer){
        if(!this.listaReniferow.contains(renifer)){
            this.listaReniferow.add(renifer);
        }
    }
    public int sumaPredkosci()
    {
        int sumaPredkosci = 0;
        for(int i=0;i<this.listaReniferow.size();i++)
        {
            sumaPredkosci+=listaReniferow.get(i).getPredkosc();
        }
        return sumaPredkosci;
    }
    public Renifer najwolniejszyRenifer()
    {
        if(this.listaReniferow.isEmpty())
            return null;
        Renifer najwolniejszyRenifer = listaReniferow.get(0);
        for(int i=0;i<this.listaReniferow.size();i++)
        {
            if(this.listaReniferow.get(i).getPredkosc()<najwolniejszyRenifer.getPredkosc())
            {
                najwolniejszyRenifer = listaReniferow.get(i);
            }
        }
        return najwolniejszyRenifer;
    }
}
