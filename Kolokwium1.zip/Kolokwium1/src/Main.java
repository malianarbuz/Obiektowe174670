public class Main {
    public static void main(String[] args) {
        int[] tab={6,4,7,4,2,0,1};
        //System.out.println(podciag(tab,2));
        System.out.println(najblizszySasiad(20));

    }
    public static boolean dokladnosc(int x,int y,int k)
    {
        x=(x+y/x)/2;
        return x - y <= Math.pow(10, -k) || x - y <= -Math.pow(10, -k);
    }
    public static int najblizszySasiad(int S)
    {
        for(int i=1;i<S/2;i++)
        {
            if (i * i > S)
                return (i-1);
        }
        return 0;
    }

    static public int podciag(int[] tab)
    {
        int dlugoscmax=0;
        int dlugosc=1;
        for(int i=1;i<tab.length;i++)
        {
            if(tab[i]<tab[i-1])
                dlugosc++;
            else
            {

                dlugosc=1;

            }
        }
        return dlugoscmax;
    }
    public static int podciag(int[] tab,int r)
    {
        int dlugoscmax=0;
        int dlugosc=1;
        for(int i=1;i<tab.length;i++)
        {
            if(tab[i]==tab[i-1]-r)
                dlugosc++;
            else
            {
                dlugoscmax=dlugosc;
                dlugosc=1;

            }
        }
        return dlugoscmax;
    }
    static public boolean czyPalindrom(int n)
    {
        int dlugosc=0;
        int m=n;
        while(m!=0)
        {
            m/=10;
            dlugosc++;
        }
        if(dlugosc<=1)
            return false;
        int[] tab=new int[dlugosc];
        for(int i=0;i<tab.length;i++)
        {
            tab[i]=n%10;
            n=n/10;
        }
        for (int i=0,k=tab.length-1;i<k;i++,k--)
        {
            if(tab[i]!=tab[k])
                return false;
        }
        return true;
    }
    static public void palindromLiczbowy(int m)
    {
        for(int i=(int)Math.pow(10,m-2);i<(int)Math.pow(10,m-1);i++)
        {
            for(int k=(int)Math.pow(10,m-2);k<(int)Math.pow(10,m-1);k++)
            {
                if(czyPalindrom(i*k))
                    System.out.println(i+" x "+k+" = "+i*k);
            }
        }
    }
}